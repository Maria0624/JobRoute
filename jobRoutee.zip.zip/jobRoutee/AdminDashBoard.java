package jobRoutee;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import db.Sql;

public class AdminDashBoard extends JFrame implements ActionListener {

    JButton userReportB, manageAccountsB, exitB;
    JButton searchByIdBtn, searchByRoleBtn, searchBtn;
    JComboBox<String> roleCombo;
    JTextField searchField;
    JButton deleteBtn, backBtn;
    JTable table;
    DefaultTableModel model;
    JFrame reportFrame;
    boolean isManageAccounts = false;

    public AdminDashBoard() {
        setTitle("Admin Dashboard");
        setSize(800, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);

        JLabel title = new JLabel("Admin Dashboard", SwingConstants.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 24));
        add(title, BorderLayout.NORTH);

        JPanel panel = new JPanel(new GridLayout(3, 1, 15, 15));

        userReportB = new JButton("User Report");
        manageAccountsB = new JButton("Manage Accounts");
        exitB = new JButton("Sign Out");

        userReportB.addActionListener(this);
        manageAccountsB.addActionListener(this);
        exitB.addActionListener(this);

        panel.add(userReportB);
        panel.add(manageAccountsB);
        panel.add(exitB);

        add(panel, BorderLayout.CENTER);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();

        if (src == userReportB) {
            isManageAccounts = false;
            openReportFrame();
        } else if (src == manageAccountsB) {
            isManageAccounts = true;
            openReportFrame();
        } else if (src == exitB) {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to sign out?", "Sign Out", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
                new MainLogin();
            }
        } else if (src == searchByIdBtn) {
            searchField.setEnabled(true);
            searchField.setText("");
            roleCombo.setEnabled(false);
        } else if (src == searchByRoleBtn) {
            roleCombo.setEnabled(true);
            searchField.setEnabled(false);
        } else if (src == searchBtn) {
            if (searchField.isEnabled()) {
                loadUsers(searchField.getText().trim(), "ID");
            } else if (roleCombo.isEnabled()) {
                loadUsers((String) roleCombo.getSelectedItem(), "Role");
            } else {
                loadUsers(null, "All");
            }
        } else if (src == deleteBtn) {
            int row = table.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(reportFrame, "Select a row to delete!");
                return;
            }
            String id = model.getValueAt(row, 0).toString();
            String role = model.getValueAt(row, 3).toString();
            int confirm = JOptionPane.showConfirmDialog(reportFrame, "Delete " + role + " with ID " + id + "?", "Confirm Delete", JOptionPane.OK_CANCEL_OPTION);
            if (confirm == JOptionPane.OK_OPTION) {
                try (Connection conn = Sql.getConnection()) {
                    PreparedStatement pst;
                    if (role.equals("JobSeeker"))
                        pst = conn.prepareStatement("DELETE FROM jobseeker WHERE jobseekerid=?");
                    else
                        pst = conn.prepareStatement("DELETE FROM recruiter WHERE institutionid=?");
                    pst.setString(1, id);
                    pst.executeUpdate();
                    JOptionPane.showMessageDialog(reportFrame, "Deleted successfully!");
                    loadUsers(null, "All");
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(reportFrame, "Error: " + ex.getMessage());
                }
            }
        } else if (src == backBtn) {
            reportFrame.dispose();
        }
    }

    private void openReportFrame() {
        reportFrame = new JFrame(isManageAccounts ? "Manage Accounts" : "User Report");
        reportFrame.setSize(900, 500);
        reportFrame.setLocationRelativeTo(this);
        reportFrame.setLayout(new BorderLayout());

        model = new DefaultTableModel();
        model.setColumnIdentifiers(new Object[]{"ID", "Name", "Email/Contact", "Role"});
        table = new JTable(model);
        JScrollPane scroll = new JScrollPane(table);
        reportFrame.add(scroll, BorderLayout.CENTER);

        JPanel topPanel = new JPanel();
        searchByIdBtn = new JButton("Search By ID");
        searchByRoleBtn = new JButton("Search By Role");
        searchBtn = new JButton("Search");
        searchField = new JTextField(15);
        roleCombo = new JComboBox<>(new String[]{"JobSeeker", "Recruiter"});

        searchField.setEnabled(false);
        roleCombo.setEnabled(false);

        searchByIdBtn.addActionListener(this);
        searchByRoleBtn.addActionListener(this);
        searchBtn.addActionListener(this);

        topPanel.add(searchByIdBtn);
        topPanel.add(searchByRoleBtn);
        topPanel.add(new JLabel("ID:"));
        topPanel.add(searchField);
        topPanel.add(new JLabel("Role:"));
        topPanel.add(roleCombo);
        topPanel.add(searchBtn);

        reportFrame.add(topPanel, BorderLayout.NORTH);

        JPanel bottomPanel = new JPanel();
        deleteBtn = new JButton("Delete Selected");
        backBtn = new JButton("Back");
        deleteBtn.addActionListener(this);
        backBtn.addActionListener(this);
        bottomPanel.add(deleteBtn);
        bottomPanel.add(backBtn);

        deleteBtn.setVisible(isManageAccounts);

        reportFrame.add(bottomPanel, BorderLayout.SOUTH);

        loadUsers(null, "All");

        reportFrame.setVisible(true);
    }

    private void loadUsers(String search, String type) {
        model.setRowCount(0);
        try (Connection conn = Sql.getConnection()) {

            if (!isManageAccounts || type.equals("All") || type.equals("ID")) {
                String jsQuery = "SELECT jobseekerid, name, email FROM jobseeker";
                if (search != null && type.equals("ID")) jsQuery += " WHERE jobseekerid='" + search + "'";
                ResultSet rs1 = conn.createStatement().executeQuery(jsQuery);
                while (rs1.next()) {
                    model.addRow(new Object[]{
                            rs1.getString("jobseekerid"),
                            rs1.getString("name"),
                            rs1.getString("email"),
                            "JobSeeker"
                    });
                }
            }

            if (!isManageAccounts || type.equals("All") || type.equals("ID")) {
                String rQuery = "SELECT institutionid, institutionname, phonenumber FROM recruiter";
                if (search != null && type.equals("ID")) rQuery += " WHERE institutionid='" + search + "'";
                ResultSet rs2 = conn.createStatement().executeQuery(rQuery);
                while (rs2.next()) {
                    model.addRow(new Object[]{
                            rs2.getString("institutionid"),
                            rs2.getString("institutionname"),
                            rs2.getString("phonenumber"),
                            "Recruiter"
                    });
                }
            }

            if (type.equals("Role") && search != null) {
                model.setRowCount(0);
                if (search.equals("JobSeeker")) {
                    String jsQuery = "SELECT jobseekerid, name, email FROM jobseeker";
                    ResultSet rs1 = conn.createStatement().executeQuery(jsQuery);
                    while (rs1.next()) {
                        model.addRow(new Object[]{
                                rs1.getString("jobseekerid"),
                                rs1.getString("name"),
                                rs1.getString("email"),
                                "JobSeeker"
                        });
                    }
                } else if (search.equals("Recruiter")) {
                    String rQuery = "SELECT institutionid, institutionname, phonenumber FROM recruiter";
                    ResultSet rs2 = conn.createStatement().executeQuery(rQuery);
                    while (rs2.next()) {
                        model.addRow(new Object[]{
                                rs2.getString("institutionid"),
                                rs2.getString("institutionname"),
                                rs2.getString("phonenumber"),
                                "Recruiter"
                        });
                    }
                }
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(reportFrame, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new AdminDashBoard();
    }
}