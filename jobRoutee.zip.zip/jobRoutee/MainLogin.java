package jobRoutee;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import db.Sql;

public class MainLogin extends JFrame implements ActionListener {
    JTextField user;
    JPasswordField pass;
    JComboBox<String> roleCombo;
    JButton loginBtn, cancelBtn;

    public MainLogin() {
        setTitle("JobRoute Login");
        setSize(400, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(4,2,10,10));

        add(new JLabel("Role:"));
        roleCombo = new JComboBox<>(new String[]{"admin", "recruiter", "jobseeker"});
        add(roleCombo);

        add(new JLabel("Username:"));
        user = new JTextField();
        add(user);

        add(new JLabel("Password:"));
        pass = new JPasswordField();
        add(pass);

        loginBtn = new JButton("Login");
        loginBtn.addActionListener(this);
        add(loginBtn);

        cancelBtn = new JButton("Cancel");
        cancelBtn.addActionListener(this);
        add(cancelBtn);

        setVisible(true);
    }
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == cancelBtn) { 
        	dispose();
        	return; 
       }
        String role = (String) roleCombo.getSelectedItem();
        String username = user.getText().trim();
        String password = new String(pass.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter username and password!");
            return;
        }
        try (Connection conn = Sql.getConnection()) {
            PreparedStatement pst;
            ResultSet rs;
            switch (role) {
                case "admin":
                    if (username.equals("admin") && password.equals("admin123")) {
                        JOptionPane.showMessageDialog(null, "Successfully logged in as Admin!");
                        new AdminDashBoard();
                        dispose();
                    } else JOptionPane.showMessageDialog(null, "Invalid admin credentials!");
                    break;
                case "recruiter":
                    pst = conn.prepareStatement(
                            "SELECT institutionid FROM recruiter WHERE institutionname=? AND password=?");
                    pst.setString(1, username);
                    pst.setString(2, password);
                    rs = pst.executeQuery();
                    if (rs.next()) {
                        String iid = rs.getString("institutionid");
                        JOptionPane.showMessageDialog(null, "Successfully logged in as Recruiter!");
                        new RecruiterDashBoard(iid);
                        dispose();
                    } 
                    else JOptionPane.showMessageDialog(null, "Invalid recruiter credentials!");
                    break;

                case "jobseeker":
                    pst = conn.prepareStatement(
                            "SELECT jobseekerid FROM jobseeker WHERE name=? AND password=?");
                    pst.setString(1, username);
                    pst.setString(2, password);
                    rs = pst.executeQuery();
                    if (rs.next()) {
                        String jsid = rs.getString("jobseekerid");
                        JOptionPane.showMessageDialog(null, "Successfully logged in as Job Seeker!");
                        new JobSeekerDashboard(jsid);
                        dispose();
                    } 
                    else JOptionPane.showMessageDialog(null, "Invalid jobseeker credentials!");
                    break;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage());
        }
    }
}