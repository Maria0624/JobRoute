package jobRoutee;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import db.Sql;

public class RecruiterDashBoard implements ActionListener {
    JFrame rf;
    JButton viewProfileB, addJobB, updateStatusB, signOutB;
    JButton updateBtn, closeBtn, backBtn,viewResumeBtn;  
    JTable appTable;
    DefaultTableModel model;
    JFrame appFrame;
    String institutionId;

    public RecruiterDashBoard(String iid) {
        this.institutionId = iid;

        rf = new JFrame("Recruiter Dashboard");
        rf.setSize(700, 450);
        rf.setLocationRelativeTo(null);
        rf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        rf.setLayout(new BorderLayout());

        JLabel lb = new JLabel("Recruiter Dashboard", SwingConstants.CENTER);
        lb.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lb.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        rf.add(lb, BorderLayout.NORTH);

        JPanel bpanel = new JPanel(new GridLayout(4, 1, 15, 15));
        bpanel.setBorder(BorderFactory.createEmptyBorder(30, 150, 30, 150));

        viewProfileB = new JButton("View Profile");
        addJobB = new JButton("Add Job Postings");
        updateStatusB = new JButton("Update Application Status");
        signOutB = new JButton("Sign Out");

        JButton[] btns = {viewProfileB, addJobB, updateStatusB, signOutB};
        for (JButton b : btns) {
            b.setFont(new Font("Segoe UI", Font.BOLD, 15));
            b.setFocusPainted(false);
            bpanel.add(b);
        }

        rf.add(bpanel, BorderLayout.CENTER);

        viewProfileB.addActionListener(this);
        addJobB.addActionListener(this);
        updateStatusB.addActionListener(this);
        signOutB.addActionListener(this);

        rf.setVisible(true);
    }

    private void openProfileWindow(String id, String name, String email, String contact, String website, String address) {
        JFrame profileFrame = new JFrame("Recruiter Profile");
        profileFrame.setSize(400, 400);
        profileFrame.setLocationRelativeTo(rf);
        profileFrame.setLayout(new BorderLayout());

        JLabel title = new JLabel("Recruiter Profile", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setBorder(BorderFactory.createEmptyBorder(15, 0, 15, 0));
        profileFrame.add(title, BorderLayout.NORTH);

        JTextArea profileArea = new JTextArea();
        profileArea.setEditable(false);
        profileArea.setFont(new Font("Segoe UI", Font.PLAIN, 15));
        profileArea.setText(
                "Institution ID: " + id + "\n" +
                "Name: " + name + "\n" +
                "Email: " + email + "\n" +
                "Contact: " + contact + "\n" +
                "Website: " + website + "\n" +
                "Address: " + address
        );

        profileFrame.add(new JScrollPane(profileArea), BorderLayout.CENTER);

        backBtn = new JButton("Back");
        backBtn.addActionListener(this);
        JPanel bottomPanel = new JPanel();
        bottomPanel.add(backBtn);
        profileFrame.add(bottomPanel, BorderLayout.SOUTH);

        profileFrame.setVisible(true);
    }

    private void viewProfile() {
        try (Connection con = Sql.getConnection()) {
            PreparedStatement pst = con.prepareStatement("SELECT * FROM recruiter WHERE institutionid=?");
            pst.setString(1, institutionId);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                openProfileWindow(
                        rs.getString("institutionid"),
                        rs.getString("institutionname"),
                        rs.getString("email"),
                        rs.getString("phonenumber"),
                        rs.getString("website"),
                        rs.getString("address")
                );
            } else {
                JOptionPane.showMessageDialog(rf, "No profile found for this ID.");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(rf, "Error: " + ex.getMessage());
        }
    }

    private void addJob() {
        JTextField titleField = new JTextField();
        JTextField skillsField = new JTextField();
        JTextArea descArea = new JTextArea(3, 20);
        Object[] message = {
                "Job Title:", titleField,
                "Skills:", skillsField,
                "Description:", new JScrollPane(descArea)
        };

        int option = JOptionPane.showConfirmDialog(rf, message, "Add Job", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String title = titleField.getText().trim();
            String skills = skillsField.getText().trim();
            String description = descArea.getText().trim();

            if (title.isEmpty() || skills.isEmpty() || description.isEmpty()) {
                JOptionPane.showMessageDialog(rf, "All fields are required!");
                return;
            }
            try (Connection con = Sql.getConnection()) {
                ResultSet rs = con.createStatement().executeQuery("SELECT COUNT(*) FROM addjob");
                int count = 0;
                if (rs.next()) count = rs.getInt(1);
                String jobid = String.format("JB%03d", count + 1);

                PreparedStatement pst = con.prepareStatement(
                        "INSERT INTO addjob (jobid, jobTitle, skills, jobDescription, institutionid) VALUES (?, ?, ?, ?, ?)");
                pst.setString(1, jobid);
                pst.setString(2, title);
                pst.setString(3, skills);
                pst.setString(4, description);
                pst.setString(5, institutionId);
                pst.executeUpdate();

                JOptionPane.showMessageDialog(rf, "Job Added Successfully!\nJob ID: " + jobid);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(rf, "Error: " + ex.getMessage());
            }
        }
    }

    private void updateApplicationStatus() {
        try (Connection con = Sql.getConnection()) {
            PreparedStatement pst = con.prepareStatement(
                "SELECT a.jobid, j.jobTitle, js.name,a.jobseekerid, a.status " +
                "FROM applicationstatus a " +
                "JOIN jobseeker js ON a.jobseekerid = js.jobseekerid " +
                "JOIN addjob j ON a.jobid = j.jobid " +
                "JOIN recruiter r ON j.institutionid = r.institutionid " +
                "WHERE r.institutionid=?"
            );
            pst.setString(1, institutionId);
            ResultSet rs = pst.executeQuery();

            String[] columns = {"Job Title","Job ID" ,"Job Seeker", "Status"};
            model = new DefaultTableModel(columns, 0);
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("jobTitle"),
                    rs.getString("jobid"),
                    rs.getString("name"),
                    rs.getString("status")
                });
            }

            if (model.getRowCount() == 0) {
                JOptionPane.showMessageDialog(rf, "No applications found for this recruiter.");
                return;
            }

            appFrame = new JFrame("Application Status");
            appFrame.setSize(700, 400);
            appFrame.setLocationRelativeTo(rf);
            appFrame.setLayout(new BorderLayout());

            appTable = new JTable(model);
            appTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            appTable.setRowHeight(25);
            appFrame.add(new JScrollPane(appTable), BorderLayout.CENTER);

            JPanel btnPanel = new JPanel();
            updateBtn = new JButton("Update Selected Status");
            viewResumeBtn = new JButton("View Resume");
            closeBtn = new JButton("Close");
            btnPanel.add(updateBtn);
            btnPanel.add(viewResumeBtn);
            btnPanel.add(closeBtn);
            appFrame.add(btnPanel, BorderLayout.SOUTH);

            updateBtn.addActionListener(this);
            viewResumeBtn.addActionListener(this);

            closeBtn.addActionListener(this);

            appFrame.setVisible(true);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(rf, "Error: " + ex.getMessage());
        }
    }

    private void refreshApplicationTable() {
        try (Connection con = Sql.getConnection()) {
            PreparedStatement pst = con.prepareStatement(
                "SELECT a.jobid, j.jobTitle, js.name, a.status " +
                "FROM applicationstatus a " +
                "JOIN jobseeker js ON a.jobseekerid = js.jobseekerid " +
                "JOIN addjob j ON a.jobid = j.jobid " +
                "JOIN recruiter r ON j.institutionid = r.institutionid " +
                "WHERE r.institutionid=?"
            );
            pst.setString(1, institutionId);
            ResultSet rs = pst.executeQuery();

            model.setRowCount(0);
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("jobTitle"),
                    rs.getString("jobid"),
                    rs.getString("name"),
                    rs.getString("status")
                });
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(appFrame, "Error refreshing: " + ex.getMessage());
        }
    }

    private void signOut() {
        int conf = JOptionPane.showConfirmDialog(rf, "Are you sure you want to sign out?", "Confirm", JOptionPane.YES_NO_OPTION);
        if (conf == JOptionPane.YES_OPTION) {
            rf.dispose();
            new MainLogin();
        }
    }

    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();

        if (src == viewProfileB) {
            viewProfile();

        } else if (src == addJobB) {
            addJob();

        } else if (src == updateStatusB) {
            updateApplicationStatus();

        } else if (src == signOutB) {
            signOut();

        } else if (src == updateBtn) {
            int selectedRow = appTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(appFrame, "Please select an application to update.");
                return;
            }
            String jobId = (String) model.getValueAt(selectedRow, 1);
            String jobSeekerName = (String) model.getValueAt(selectedRow, 2);

            String jobSeekerId = "";
            try (Connection con = Sql.getConnection()) {
                PreparedStatement ps = con.prepareStatement("SELECT jobseekerid FROM jobseeker WHERE name=?");
                ps.setString(1, jobSeekerName);
                ResultSet r = ps.executeQuery();
                if (r.next()) jobSeekerId = r.getString(1);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(appFrame, "Error fetching jobseeker ID: " + ex.getMessage());
            }

            String[] statuses = {"Pending", "Reviewed", "Accepted", "Rejected"};
            String newStatus = (String) JOptionPane.showInputDialog(appFrame, "Select new status:", "Update Status",
                    JOptionPane.QUESTION_MESSAGE, null, statuses, model.getValueAt(selectedRow, 3));

            if (newStatus != null) {
                try (Connection con = Sql.getConnection()) {
                    PreparedStatement updatePst = con.prepareStatement(
                            "UPDATE applicationstatus SET status=? WHERE jobid=? AND jobseekerid=?");
                    updatePst.setString(1, newStatus);
                    updatePst.setString(2, jobId);
                    updatePst.setString(3, jobSeekerId);
                    updatePst.executeUpdate();

                    JOptionPane.showMessageDialog(appFrame, "Status updated successfully!");
                    refreshApplicationTable();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(appFrame, "Error updating status: " + ex.getMessage());
                }
            }}
            else if (src == viewResumeBtn) {
                int selectedRow = appTable.getSelectedRow();
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(appFrame, "Please select an application first.");
                    return;
                }

                String jobid = (String) model.getValueAt(selectedRow, 1);
                String name = (String) model.getValueAt(selectedRow, 2);
                String resumePath = null;

                try (Connection con = Sql.getConnection()) {
                    PreparedStatement ps = con.prepareStatement(
                        "SELECT resumePath FROM applicationstatus a " +
                        "JOIN jobseeker js ON a.jobseekerid = js.jobseekerid " +
                        "WHERE a.jobid=? AND js.name=?"
                    );
                    ps.setString(1, jobid);
                    ps.setString(2, name);
                    ResultSet rs = ps.executeQuery();
                    if (rs.next()) {
                        resumePath = rs.getString("resumePath");
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(appFrame, "Error fetching resume: " + ex.getMessage());
                    return;
                }

                if (resumePath != null && !resumePath.trim().isEmpty()) {
                    try {
                        Desktop.getDesktop().open(new java.io.File(resumePath));
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(appFrame, "Unable to open resume file: " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(appFrame, "No resume uploaded for this application.");
                }
            } 
        else if (src == closeBtn || src == backBtn) {
            JFrame frame = (JFrame) SwingUtilities.getWindowAncestor((Component) src);
            frame.dispose();
            rf.setVisible(true); 
        }
    }}
    
