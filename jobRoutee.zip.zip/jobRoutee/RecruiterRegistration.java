package jobRoutee;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import db.Sql;

public class RecruiterRegistration implements ActionListener {

    JFrame f;
    JTextField tName, tAddress, tPhone, tWebsite, tEmail;
    JPasswordField tPassword;
    JButton registerBtn, cancelBtn;

    public RecruiterRegistration() {
        f = new JFrame("Recruiter (Institution) Registration");
        f.setSize(450, 400);
        f.setLocationRelativeTo(null);
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel p = new JPanel(new GridLayout(8, 2, 10, 10));
        p.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        
        p.add(new JLabel("Institution Name:"));
        tName = new JTextField(); 
        p.add(tName);

        p.add(new JLabel("Address:"));
        tAddress = new JTextField(); 
        p.add(tAddress);

        p.add(new JLabel("Phone Number:"));
        tPhone = new JTextField(); 
        p.add(tPhone);

        p.add(new JLabel("Website:"));
        tWebsite = new JTextField(); 
        p.add(tWebsite);

        p.add(new JLabel("Email:"));
        tEmail = new JTextField(); 
        p.add(tEmail);

        p.add(new JLabel("Password:"));
        tPassword = new JPasswordField(); 
        p.add(tPassword);

        registerBtn = new JButton("Register"); 
        registerBtn.addActionListener(this);
        cancelBtn = new JButton("Cancel"); 
        cancelBtn.addActionListener(this);

        p.add(registerBtn); 
        p.add(cancelBtn);

        f.add(p);
        f.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == cancelBtn) {
            f.dispose();
            return;
        }

        String name = tName.getText().trim();
        String address = tAddress.getText().trim();
        String phone = tPhone.getText().trim();
        String website = tWebsite.getText().trim();
        String email = tEmail.getText().trim();
        String password = new String(tPassword.getPassword()).trim();

        if (name.isEmpty() || address.isEmpty() || phone.isEmpty() || website.isEmpty() || email.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(f, "Please fill all fields!");
            return;
        }
        if (!phone.matches("\\d{10}")) {
            JOptionPane.showMessageDialog(f, "Phone number must be 10 digits!");
            return;
        }

        try (Connection con = Sql.getConnection()) {
            ResultSet rs = con.createStatement().executeQuery("SELECT COUNT(*) FROM recruiter");
            int count = 0;
            if (rs.next()) count = rs.getInt(1);
            String rid = String.format("I%03d", count + 1);
            PreparedStatement pst = con.prepareStatement("INSERT INTO recruiter (institutionid, institutionName, "
            		+ "address, password, phonenumber, website, email) VALUES (?,?,?,?,?,?,?)"
            );
            pst.setString(1, rid);
            pst.setString(2, name);
            pst.setString(3, address);
            pst.setString(4, password);
            pst.setString(5, phone);
            pst.setString(6, website);
            pst.setString(7, email);

            int res = pst.executeUpdate();

            if (res > 0) {
                JOptionPane.showMessageDialog(f, 
                    "Registration Successful!\nInstitution ID: " + rid + 
                    "\nPlease use your ID and password to log in.");
                f.dispose();
                new RecruiterDashBoard(rid); 
            } else {
                JOptionPane.showMessageDialog(f, "Registration failed!");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(f, "Error: " + ex.getMessage());
        }
    }
}