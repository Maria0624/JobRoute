package jobRoutee;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Main extends JFrame implements ActionListener {
    JButton nb, rb;

    public Main() {
        setTitle("JobRoute");
        setSize(450, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        
        JLabel l1 = new JLabel("Welcome to", SwingConstants.CENTER);
        JLabel l2 = new JLabel("JOB ROUTE", SwingConstants.CENTER);
        JLabel l3 = new JLabel("Job Recruitement Management System",SwingConstants.CENTER);
        l1.setFont(new Font("Arial", Font.PLAIN, 20));
        l2.setFont(new Font("SansSerif", Font.BOLD, 32));
      
        JPanel p = new JPanel(new GridLayout(3, 1, 0,15));
        p.add(l1);
        p.add(l2);
        p.add(l3);
        add(p, BorderLayout.CENTER);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));

        nb = new JButton("Next");
        nb.setFont(new Font("SansSerif", Font.BOLD, 16));
        nb.addActionListener(this);

        rb = new JButton("Register");
        rb.setFont(new Font("SansSerif", Font.BOLD, 16));
        rb.addActionListener(this);

        btnPanel.add(nb);
        btnPanel.add(rb);
        add(btnPanel, BorderLayout.SOUTH);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == nb) {
            new MainLogin();
            dispose();
        } else if (e.getSource() == rb) {
            String[] options = {"Job Seeker", "Recruiter"};
            int choice = JOptionPane.showOptionDialog(this,"Select registration type:","Register",JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,null,options,options[0]);

            if (choice == 0) new JobSeekerRegistration();
            else if (choice == 1) new RecruiterRegistration();
        }
    }

    public static void main(String[] args) {
        new Main();
    }
}