package jobRoutee;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;
import db.Sql;
public class JobSeekerDashboard implements ActionListener {

    JFrame jsf, profileFrame, jobsFrame, appFrame;
    JButton viewProfileBtn, viewJobsBtn, viewApplicationsBtn, signOutBtn;
    JButton editBtn, backBtnProfile, backBtnJobs, backBtnApps;
    JTextArea profileDetails;
    String jId;
    public JobSeekerDashboard(String jobseekerId){
        this.jId = jobseekerId;
        jsf = new JFrame("Job Seeker Dashboard");
        jsf.setSize(700,450);
        jsf.setLocationRelativeTo(null);
        jsf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jsf.setLayout(new BorderLayout());
        
        JLabel heading = new JLabel("Job Seeker Dashboard", SwingConstants.CENTER);
        heading.setFont(new Font("Segoe UI", Font.BOLD, 22));
        heading.setBorder(BorderFactory.createEmptyBorder(20,0,20,0));
        jsf.add(heading, BorderLayout.NORTH);

        JPanel btnPanel = new JPanel(new GridLayout(4,1,15,15));
        btnPanel.setBorder(BorderFactory.createEmptyBorder(30,120,30,120));

        viewProfileBtn = new JButton("View Profile");
        viewJobsBtn = new JButton("View Job Postings");
        viewApplicationsBtn = new JButton("View Applications");
        signOutBtn = new JButton("Sign Out");
        
        btnPanel.add(viewProfileBtn);
        btnPanel.add(viewJobsBtn);
        btnPanel.add(viewApplicationsBtn);
        btnPanel.add(signOutBtn);
        jsf.add(btnPanel, BorderLayout.CENTER);
        viewProfileBtn.addActionListener(this);
        viewJobsBtn.addActionListener(this);
        viewApplicationsBtn.addActionListener(this);
        signOutBtn.addActionListener(this);
        jsf.setVisible(true);
    }
    private void openProfileWindow() {
        profileFrame = new JFrame("My Profile");
        profileFrame.setSize(500,400);
        profileFrame.setLocationRelativeTo(jsf);
        profileFrame.setLayout(new BorderLayout());
        profileDetails = new JTextArea();
        profileDetails.setEditable(false);     
        JScrollPane scroll = new JScrollPane(profileDetails);
        profileFrame.add(scroll, BorderLayout.CENTER);
        JPanel btnPanel = new JPanel();
        editBtn = new JButton("Edit");
        backBtnProfile = new JButton("Back");
        editBtn.addActionListener(this);
        backBtnProfile.addActionListener(this);
        btnPanel.add(editBtn);
        btnPanel.add(backBtnProfile);
        profileFrame.add(btnPanel, BorderLayout.SOUTH);
        loadProfileData();
        jsf.setVisible(false);
        profileFrame.setVisible(true);
    }
    private void loadProfileData() {
        try(Connection con = Sql.getConnection()){
            PreparedStatement pst = con.prepareStatement("SELECT * FROM jobseeker WHERE jobseekerid=?");
            pst.setString(1, jId);
            ResultSet rs = pst.executeQuery();
            if(rs.next()){
                profileDetails.setText(
                    "Job Seeker ID: " + rs.getString("jobseekerid") + "\n" +
                    "Name: " + rs.getString("name") + "\n" +
                    "Email: " + rs.getString("email") + "\n" +
                    "Qualifications: " + rs.getString("qualifications") + "\n" +
                    "Skills: " + rs.getString("skills")
                );
            } else {
                profileDetails.setText("Profile not found!");
            }
        } catch(Exception ex){
            JOptionPane.showMessageDialog(profileFrame,"Error: "+ex.getMessage());
        }
    }
    private void openEditProfile(){
        try(Connection con = Sql.getConnection()){
            PreparedStatement pst = con.prepareStatement("SELECT * FROM jobseeker WHERE jobseekerid=?");
            pst.setString(1, jId);
            ResultSet rs = pst.executeQuery();
            if(rs.next()){
                JTextField nameF = new JTextField(rs.getString("name"));
                JTextField emailF = new JTextField(rs.getString("email"));
                JTextField qualF = new JTextField(rs.getString("qualifications"));
                JTextField skillsF = new JTextField(rs.getString("skills"));
                Object[] fields = {"Name:", nameF,"Email:", emailF,"Qualifications:", qualF,"Skills:", skillsF};
                int ok = JOptionPane.showConfirmDialog
                		(profileFrame, fields, "Edit Profile", JOptionPane.OK_CANCEL_OPTION);
                if(ok == JOptionPane.OK_OPTION){
                    PreparedStatement upd = con.prepareStatement(
                        "UPDATE jobseeker SET name=?, email=?, qualifications=?, "
                        + "skills=? WHERE jobseekerid=?");
                    upd.setString(1, nameF.getText());
                    upd.setString(2, emailF.getText());
                    upd.setString(3, qualF.getText());
                    upd.setString(4, skillsF.getText());
                    upd.setString(5, jId);
                    upd.executeUpdate();
                    JOptionPane.showMessageDialog(profileFrame,"Profile updated successfully!");
                    loadProfileData();
                }
            }
        } catch(Exception ex){
            JOptionPane.showMessageDialog(profileFrame,"Error: "+ex.getMessage());
        }
    }
    private void openJobListingsWindow() {
        jobsFrame = new JFrame("Available Job Postings");
        jobsFrame.setSize(700,500);
        jobsFrame.setLocationRelativeTo(jsf);
        jobsFrame.setLayout(new BorderLayout());

        JPanel jobPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        JScrollPane scroll = new JScrollPane(jobPanel);
        jobsFrame.add(scroll, BorderLayout.CENTER);

        backBtnJobs = new JButton("Back");
        backBtnJobs.addActionListener(this);
        JPanel bottomPanel = new JPanel();
        bottomPanel.add(backBtnJobs);
        jobsFrame.add(bottomPanel, BorderLayout.SOUTH);

        try(Connection con = Sql.getConnection()){
            PreparedStatement pst = con.prepareStatement("SELECT jobid, jobTitle, skills,jobDescription FROM addjob");
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
                String jobid = rs.getString("jobid");
                String title = rs.getString("jobTitle");
                String skills = rs.getString("skills");
                String jobDescription=rs.getString("jobDescription");

                JPanel card = new JPanel();
                card.setPreferredSize(new Dimension(300,120));
                card.setBorder(BorderFactory.createLineBorder(Color.GRAY));
                card.setLayout(new BorderLayout());

                JTextArea info = new JTextArea(
                    "Job ID: " + jobid + "\nTitle: " + title + "\nSkills: " + skills+"\nJobDescription: "+jobDescription);
                info.setEditable(false);
                card.add(info, BorderLayout.CENTER);

                JButton applyBtn = new JButton("Apply Now");
                applyBtn.putClientProperty("jobid", jobid); 
                applyBtn.addActionListener(this);
                card.add(applyBtn, BorderLayout.SOUTH);

                jobPanel.add(card);
            }
        } catch(Exception ex){
            JOptionPane.showMessageDialog(jobsFrame,"Error: "+ex.getMessage());
        }
        jsf.setVisible(false);
        jobsFrame.setVisible(true);
    }
    private void applyForJob(String clickedJobId) {
        String jobIdStr = JOptionPane.showInputDialog(jsf, "Enter Job ID to apply:", clickedJobId);
        if (jobIdStr == null || jobIdStr.trim().isEmpty()) 
            return;
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Select Resume File");
        int option = fileChooser.showOpenDialog(jsf);
        String resumePath = null;
        if (option == JFileChooser.APPROVE_OPTION) {
            resumePath = fileChooser.getSelectedFile().getAbsolutePath();
            JOptionPane.showMessageDialog(jsf, "Selected Resume: " + resumePath);
        } else {
            JOptionPane.showMessageDialog(jsf, "Resume not selected. Application cancelled.");
            return;
        }
        try (Connection con = Sql.getConnection()) {
            PreparedStatement jobCheck = con.prepareStatement("SELECT jobTitle FROM addjob WHERE jobid=?");
            jobCheck.setString(1, jobIdStr);
            ResultSet rsJob = jobCheck.executeQuery();
            if (!rsJob.next()) {
                JOptionPane.showMessageDialog(jsf, "Job not found!");
                return;
            }
            String jobTitle = rsJob.getString("jobTitle");
            PreparedStatement seekerSmt=con.prepareStatement("SELECT * FROM jobseeker WHERE jobseekerid=?");
            seekerSmt.setString(1,jId);
            ResultSet rsSeeker = seekerSmt.executeQuery();
            if (!rsSeeker.next()) {
                JOptionPane.showMessageDialog(jsf, "Job Seeker not found in jobseeker table!");
                return;
            }

            PreparedStatement check = con.prepareStatement(
                "SELECT * FROM applicationstatus WHERE jobTitle=? AND jobseekerid=?"
            );
            check.setString(1, jobTitle);
            check.setString(2, jId);
            ResultSet rsCheck = check.executeQuery();
            if (rsCheck.next()) {
                JOptionPane.showMessageDialog(jsf, "You have already applied for this job!");
                return;
            }
            PreparedStatement insert = con.prepareStatement(
                "INSERT INTO applicationstatus (jobTitle, jobid, jobseekerid, status,resumePath) VALUES (?, ?, ?, ?,?)"
            );
            insert.setString(1, jobTitle);
            insert.setString(2, jobIdStr);
            insert.setString(3, jId);
            insert.setString(4, "Pending");
            insert.setString(5, resumePath);
            int rows = insert.executeUpdate();
            if (rows > 0) {
                JOptionPane.showMessageDialog(jsf, "Application submitted successfully!");
            } else {
                JOptionPane.showMessageDialog(jsf, "Failed to apply. Please try again.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(jsf, "Error: " + e.getMessage());
        }
    }
    
    
    private void openApplicationsWindow() {
        appFrame = new JFrame("My Applications");
        appFrame.setSize(700,500);
        appFrame.setLocationRelativeTo(jsf);
        appFrame.setLayout(new BorderLayout());
        DefaultTableModel appModel = new DefaultTableModel();
        appModel.setColumnIdentifiers(new Object[]{"Job Title","Job ID","JobSeeker ID","Status"});
        JTable appTable = new JTable(appModel);
        JScrollPane scroll = new JScrollPane(appTable);
        appFrame.add(scroll, BorderLayout.CENTER);
        backBtnApps = new JButton("Back");
        backBtnApps.addActionListener(this);
        JPanel bottomPanel = new JPanel();
        bottomPanel.add(backBtnApps);
        appFrame.add(bottomPanel, BorderLayout.SOUTH);
        try(Connection con = Sql.getConnection()){
            PreparedStatement pst = con.prepareStatement(
                "SELECT j.jobTitle,a.jobid,a.jobseekerid, a.status " +
                "FROM applicationstatus a"+" JOIN addjob j ON a.jobid=j.jobid " +"JOIN jobseeker jb ON a.jobseekerid=jb.jobseekerid "+
                "WHERE a.jobseekerid=?");
            pst.setString(1, jId);
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
                appModel.addRow(new Object[]{
                    rs.getString("jobTitle"),
                    rs.getString("jobid"),
                    rs.getString("jobseekerid"),
                    rs.getString("status")
                });
            }
        } catch(Exception ex){
            JOptionPane.showMessageDialog(appFrame,"Error: "+ex.getMessage());
        }
        jsf.setVisible(false);
        appFrame.setVisible(true);
    }
    private void signOut(){
        int conf = JOptionPane.showConfirmDialog(jsf, "Are you sure you want to sign out?", "Confirm", JOptionPane.YES_NO_OPTION);
        if(conf == JOptionPane.YES_OPTION){
            jsf.dispose();
            new MainLogin();
        }
    }
    public void actionPerformed(ActionEvent e){
        Object src = e.getSource();
        if(src == viewProfileBtn)
            openProfileWindow();
        else if(src == viewJobsBtn)
            openJobListingsWindow();
        else if(src == viewApplicationsBtn)
            openApplicationsWindow();
        else if(src == signOutBtn)
            signOut();
        else if(src == editBtn)
            openEditProfile();
        else if(src == backBtnProfile){
            profileFrame.dispose();
            jsf.setVisible(true);
        }
        else if(src == backBtnJobs){
            jobsFrame.dispose();
            jsf.setVisible(true);
        }
        else if(src == backBtnApps){
            appFrame.dispose();
            jsf.setVisible(true);
        }
        else if(src instanceof JButton){ 
            JButton btn = (JButton) src;
            
            Object jobObj = btn.getClientProperty("jobid");
            if(jobObj != null && btn.getText().equals("Apply Now")) {
                String jobid = (String) jobObj;
                int confirm=JOptionPane.showConfirmDialog(jsf, "Do you want to apply for this job?","Confirm Application",JOptionPane.YES_NO_OPTION);
                if(confirm==JOptionPane.YES_OPTION) {
                applyForJob(jobid);
            }
        }
    }
    }
}
