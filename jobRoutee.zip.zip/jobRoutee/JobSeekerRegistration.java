package jobRoutee;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import db.Sql;

public class JobSeekerRegistration implements ActionListener {

    JFrame f;
    JTextField tName, tEmail, tQual, tSkills;
    JPasswordField tPass;
    JButton registerBtn, cancelBtn;

    public JobSeekerRegistration() {
        f = new JFrame("Job Seeker Registration");
        f.setSize(400, 300);
        f.setLocationRelativeTo(null);
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel p = new JPanel(new GridLayout(6, 2, 10, 10));
        p.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        p.add(new JLabel("Name:"));
        tName = new JTextField(); p.add(tName);

        p.add(new JLabel("Email:"));
        tEmail = new JTextField(); p.add(tEmail);

        p.add(new JLabel("Qualification:"));
        tQual = new JTextField(); p.add(tQual);

        p.add(new JLabel("Skills:"));
        tSkills = new JTextField(); p.add(tSkills);
        
        p.add(new JLabel("password:"));
        tPass=new JPasswordField();
        p.add(tPass);
        
        registerBtn = new JButton("Register"); registerBtn.addActionListener(this);
        cancelBtn = new JButton("Cancel"); cancelBtn.addActionListener(this);
        p.add(registerBtn); p.add(cancelBtn);

        f.add(p);
        f.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == cancelBtn){ f.dispose(); return; }

        String name = tName.getText().trim();
        String email = tEmail.getText().trim();
        String qual = tQual.getText().trim();
        String skills = tSkills.getText().trim();
        String password = new String(tPass.getPassword()).trim();

        if(name.isEmpty() || email.isEmpty() || qual.isEmpty() || skills.isEmpty()){
            JOptionPane.showMessageDialog(f,"Please fill all fields!"); return;
        }

        try(Connection con = Sql.getConnection()){
            ResultSet rs = con.createStatement().executeQuery("SELECT COUNT(*) FROM jobseeker");
            int count = 0; if(rs.next()) count = rs.getInt(1);
            String jsid = String.format("J%03d", count+1);

            PreparedStatement pst = con.prepareStatement(
                "INSERT INTO jobseeker (jobseekerid, name, email, qualifications, skills, password) VALUES (?,?,?,?,?,?)");
            pst.setString(1, jsid);
            pst.setString(2, name);
            pst.setString(3, email);
            pst.setString(4, qual);
            pst.setString(5, skills);
            pst.setString(6, password);
            int res = pst.executeUpdate();

            if(res>0){
                JOptionPane.showMessageDialog(f,"Registered! ID: "+jsid);
                f.dispose();
                new JobSeekerDashboard(jsid);
            } else JOptionPane.showMessageDialog(f,"Registration failed!");

        } catch(Exception ex){ JOptionPane.showMessageDialog(f,"Error: "+ex.getMessage()); }
    }
}